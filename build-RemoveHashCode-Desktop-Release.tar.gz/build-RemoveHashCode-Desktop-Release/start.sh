#!/bin/bash
argc=$#
argv1=$1
argv2=$2
argv3=$3
echo $argv1
echo $argv2
echo $argv3

fa_argcv()
{
	if [ 2 -eq $argc ]
	then
		CUR_PATH=$(pwd)
		export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$CUR_PATH/lib
		$CUR_PATH/RemoveHashCode -i $argv1 -vcodec h264 -vf hflip -crf 23 -preset ultrafast -g 50 -bufsize 5120k -r 25 -acodec mp3 $argv2
	elif [ 3 -eq $argc ]
	then
		CUR_PATH=$(pwd)
		export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$CUR_PATH/lib
		$CUR_PATH/RemoveHashCode -i $argv1 -chinfo $argv3 -vcodec h264 -crf 23 -preset ultrafast -g 30 -bufsize 5120k -r 15 -acodec mp3 -f mpegts $argv2  
	else
		echo "usage: ./start.sh input(stream/file) output(stream/file)"
	fi
}
fa_argcv
exit 0
